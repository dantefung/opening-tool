package ${PACKAGE_NAME};

import lombok.Data;

import java.io.Serializable;

@Data
public class ${NAME}UpdateDTO implements Serializable {

	private static final long serialVersionUID = -5490907874612876681L;

	
}