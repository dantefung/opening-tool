package ${PACKAGE_NAME};


import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

@Data
@Accessors(chain = true)
public class ${NAME}GetDTO implements Serializable {

	private static final long serialVersionUID = -5266266874133128159L;

}