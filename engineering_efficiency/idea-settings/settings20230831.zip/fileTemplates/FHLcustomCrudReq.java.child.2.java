package ${PACKAGE_NAME};

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class ${NAME}GetReq implements Serializable {

	private static final long serialVersionUID = -2147390500705375962L;

	/**
	 * 记录ID
	 */
	@NotNull
	private Long id;
}
