package ${PACKAGE_NAME};


import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@Accessors(chain = true)
public class ${NAME}ListDTO implements Serializable {

	private static final long serialVersionUID = -4253393947763665529L;

	
}