package ${PACKAGE_NAME};

import com.zuzuche.ercpservice.common.model.BaseWebReq;
import com.zuzuche.ercpservice.common.validator.ParamValidator;

@Data
public class ${NAME}AddReq extends BaseWebReq implements Serializable, ParamValidator {

	private static final long serialVersionUID = -8280634904176539948L;


	public Long getId() {
		return null;
	}

	@Override
	public void validate() {
		
	}
}