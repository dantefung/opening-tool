/*
 * Copyright (C), 2015-2020
 * FileName: ${NAME}
 * Author:   fenghaolin@zuzuche.com
 * Date:     ${DATE} ${TIME}
 * Description: ${todo}
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 * fenghaolin@zuzuche.com        ${DATE} ${TIME}   V1.0.0            
 */
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public class ${NAME} {
}
