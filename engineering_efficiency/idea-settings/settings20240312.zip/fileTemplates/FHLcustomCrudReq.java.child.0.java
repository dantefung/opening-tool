package ${PACKAGE_NAME};

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class ${NAME}UpdateReq extends ${NAME}AddReq implements Serializable {

	private static final long serialVersionUID = 2750340028534087539L;

	/**
	 * 记录ID
	 */
	@NotNull
	private Long id;
}
