package ${PACKAGE_NAME};


import lombok.Data;

import java.io.Serializable;

@Data
public class ${NAME}AddDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	
}