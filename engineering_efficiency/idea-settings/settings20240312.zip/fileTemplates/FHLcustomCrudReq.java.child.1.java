package ${PACKAGE_NAME};

import lombok.Data;

import java.io.Serializable;

@Data
public class ${NAME}ListReq implements Serializable {

	private static final long serialVersionUID = -6247547314928773682L;

	/**
	 * 分页号
	 */
	private int pageNo = 1;

	/**
	 * 页大小
	 */
	private int pageSize = 15;

	/**
	 * all=1 查询全部
	 * all=0 则按分页参数pageNo和pageSize查询
	 */
	private int all;


}