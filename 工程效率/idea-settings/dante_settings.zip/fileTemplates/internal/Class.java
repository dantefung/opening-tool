/*
 * Copyright (C), 2015-2018
 * FileName: ${NAME}
 * Author:   DANTE FUNG
 * Date:     ${DATE} ${TIME}
 * Description: ${todo}
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 * DANTE FUNG        ${DATE} ${TIME}   V1.0.0            
 */
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public class ${NAME} {
}
